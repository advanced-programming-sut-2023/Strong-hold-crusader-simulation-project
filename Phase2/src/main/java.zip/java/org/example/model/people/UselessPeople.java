package org.example.model.people;

public class UselessPeople {
    public UselessPeople(){

    }
}
