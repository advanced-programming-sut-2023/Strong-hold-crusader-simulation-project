package org.example.model;

public enum AnimalType {
    WarDog;
}
